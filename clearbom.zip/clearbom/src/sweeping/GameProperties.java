package sweeping;

public class GameProperties {
	public static int row=10;
	public static int col=10;
	public static int bom_cnt=10;
	static public int BOMCODE = 10;
	static public final int game_width=1040;
	static public final int game_higth=800;
	static public int Bom_len=0;
}
